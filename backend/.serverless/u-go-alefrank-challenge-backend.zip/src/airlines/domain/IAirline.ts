export interface IAirline {
  name: string

  code: string

  isLowCost: string
}
