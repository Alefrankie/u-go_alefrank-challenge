export class FindFlightsDTO {
  origin: string
  destination: string
  budget: number
}
