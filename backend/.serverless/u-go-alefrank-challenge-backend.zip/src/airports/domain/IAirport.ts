export class IAirport {
  cityCode: string

  countryCode: string

  name: string

  code: string
}
