export class FilterByKeyDTO {
  key: string
}
