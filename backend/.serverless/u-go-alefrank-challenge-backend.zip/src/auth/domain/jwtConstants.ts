export const jwtConstants = {
  secret: 'secret'
}
